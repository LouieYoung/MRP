package entity;

public class TPOP {
    private int id;
    private String P_No;
    private String OH;
    private String AL;
    private int LT;
    private int ST;
    private int SS;
    private String LSR;
    private int LS;

    private int GR0;
    private int GR1;
    private int GR2;
    private int GR3;
    private int GR4;
    private int GR5;
    private int GR6;
    private int GR7;
    private int GR8;
    private int GR9;
    private int GR10;
    private int GR11;
    private int GR12;

    private int SR0;
    private int SR1;
    private int SR2;
    private int SR3;
    private int SR4;
    private int SR5;
    private int SR6;
    private int SR7;
    private int SR8;
    private int SR9;
    private int SR10;
    private int SR11;
    private int SR12;

    private int POH0;
    private int POH1;
    private int POH2;
    private int POH3;
    private int POH4;
    private int POH5;
    private int POH6;
    private int POH7;
    private int POH8;
    private int POH9;
    private int POH10;
    private int POH11;
    private int POH12;

    private int PAB0;
    private int PAB1;
    private int PAB2;
    private int PAB3;
    private int PAB4;
    private int PAB5;
    private int PAB6;
    private int PAB7;
    private int PAB8;
    private int PAB9;
    private int PAB10;
    private int PAB11;
    private int PAB12;

    private int NR0;
    private int NR1;
    private int NR2;
    private int NR3;
    private int NR4;
    private int NR5;
    private int NR6;
    private int NR7;
    private int NR8;
    private int NR9;
    private int NR10;
    private int NR11;
    private int NR12;

    private int PORcpt0;
    private int PORcpt1;
    private int PORcpt2;
    private int PORcpt3;
    private int PORcpt4;
    private int PORcpt5;
    private int PORcpt6;
    private int PORcpt7;
    private int PORcpt8;
    private int PORcpt9;
    private int PORcpt10;
    private int PORcpt11;
    private int PORcpt12;

    private int POR0;
    private int POR1;
    private int POR2;
    private int POR3;
    private int POR4;
    private int POR5;
    private int POR6;
    private int POR7;
    private int POR8;
    private int POR9;
    private int POR10;
    private int POR11;
    private int POR12;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getP_No() {
        return P_No;
    }

    public void setP_No(String p_No) {
        P_No = p_No;
    }

    public String getOH() {
        return OH;
    }

    public void setOH(String OH) {
        this.OH = OH;
    }

    public String getAL() {
        return AL;
    }

    public void setAL(String AL) {
        this.AL = AL;
    }

    public int getLT() {
        return LT;
    }

    public void setLT(int LT) {
        this.LT = LT;
    }

    public int getST() {
        return ST;
    }

    public void setST(int ST) {
        this.ST = ST;
    }

    public int getSS() {
        return SS;
    }

    public void setSS(int SS) {
        this.SS = SS;
    }

    public String getLSR() {
        return LSR;
    }

    public void setLSR(String LSR) {
        this.LSR = LSR;
    }

    public int getLS() {
        return LS;
    }

    public void setLS(int LS) {
        this.LS = LS;
    }

    public int getGR0() {
        return GR0;
    }

    public void setGR0(int GR0) {
        this.GR0 = GR0;
    }

    public int getGR1() {
        return GR1;
    }

    public void setGR1(int GR1) {
        this.GR1 = GR1;
    }

    public int getGR2() {
        return GR2;
    }

    public void setGR2(int GR2) {
        this.GR2 = GR2;
    }

    public int getGR3() {
        return GR3;
    }

    public void setGR3(int GR3) {
        this.GR3 = GR3;
    }

    public int getGR4() {
        return GR4;
    }

    public void setGR4(int GR4) {
        this.GR4 = GR4;
    }

    public int getGR5() {
        return GR5;
    }

    public void setGR5(int GR5) {
        this.GR5 = GR5;
    }

    public int getGR6() {
        return GR6;
    }

    public void setGR6(int GR6) {
        this.GR6 = GR6;
    }

    public int getGR7() {
        return GR7;
    }

    public void setGR7(int GR7) {
        this.GR7 = GR7;
    }

    public int getGR8() {
        return GR8;
    }

    public void setGR8(int GR8) {
        this.GR8 = GR8;
    }

    public int getGR9() {
        return GR9;
    }

    public void setGR9(int GR9) {
        this.GR9 = GR9;
    }

    public int getGR10() {
        return GR10;
    }

    public void setGR10(int GR10) {
        this.GR10 = GR10;
    }

    public int getGR11() {
        return GR11;
    }

    public void setGR11(int GR11) {
        this.GR11 = GR11;
    }

    public int getGR12() {
        return GR12;
    }

    public void setGR12(int GR12) {
        this.GR12 = GR12;
    }

    public int getSR0() {
        return SR0;
    }

    public void setSR0(int SR0) {
        this.SR0 = SR0;
    }

    public int getSR1() {
        return SR1;
    }

    public void setSR1(int SR1) {
        this.SR1 = SR1;
    }

    public int getSR2() {
        return SR2;
    }

    public void setSR2(int SR2) {
        this.SR2 = SR2;
    }

    public int getSR3() {
        return SR3;
    }

    public void setSR3(int SR3) {
        this.SR3 = SR3;
    }

    public int getSR4() {
        return SR4;
    }

    public void setSR4(int SR4) {
        this.SR4 = SR4;
    }

    public int getSR5() {
        return SR5;
    }

    public void setSR5(int SR5) {
        this.SR5 = SR5;
    }

    public int getSR6() {
        return SR6;
    }

    public void setSR6(int SR6) {
        this.SR6 = SR6;
    }

    public int getSR7() {
        return SR7;
    }

    public void setSR7(int SR7) {
        this.SR7 = SR7;
    }

    public int getSR8() {
        return SR8;
    }

    public void setSR8(int SR8) {
        this.SR8 = SR8;
    }

    public int getSR9() {
        return SR9;
    }

    public void setSR9(int SR9) {
        this.SR9 = SR9;
    }

    public int getSR10() {
        return SR10;
    }

    public void setSR10(int SR10) {
        this.SR10 = SR10;
    }

    public int getSR11() {
        return SR11;
    }

    public void setSR11(int SR11) {
        this.SR11 = SR11;
    }

    public int getSR12() {
        return SR12;
    }

    public void setSR12(int SR12) {
        this.SR12 = SR12;
    }

    public int getPOH0() {
        return POH0;
    }

    public void setPOH0(int POH0) {
        this.POH0 = POH0;
    }

    public int getPOH1() {
        return POH1;
    }

    public void setPOH1(int POH1) {
        this.POH1 = POH1;
    }

    public int getPOH2() {
        return POH2;
    }

    public void setPOH2(int POH2) {
        this.POH2 = POH2;
    }

    public int getPOH3() {
        return POH3;
    }

    public void setPOH3(int POH3) {
        this.POH3 = POH3;
    }

    public int getPOH4() {
        return POH4;
    }

    public void setPOH4(int POH4) {
        this.POH4 = POH4;
    }

    public int getPOH5() {
        return POH5;
    }

    public void setPOH5(int POH5) {
        this.POH5 = POH5;
    }

    public int getPOH6() {
        return POH6;
    }

    public void setPOH6(int POH6) {
        this.POH6 = POH6;
    }

    public int getPOH7() {
        return POH7;
    }

    public void setPOH7(int POH7) {
        this.POH7 = POH7;
    }

    public int getPOH8() {
        return POH8;
    }

    public void setPOH8(int POH8) {
        this.POH8 = POH8;
    }

    public int getPOH9() {
        return POH9;
    }

    public void setPOH9(int POH9) {
        this.POH9 = POH9;
    }

    public int getPOH10() {
        return POH10;
    }

    public void setPOH10(int POH10) {
        this.POH10 = POH10;
    }

    public int getPOH11() {
        return POH11;
    }

    public void setPOH11(int POH11) {
        this.POH11 = POH11;
    }

    public int getPOH12() {
        return POH12;
    }

    public void setPOH12(int POH12) {
        this.POH12 = POH12;
    }

    public int getPAB0() {
        return PAB0;
    }

    public void setPAB0(int PAB0) {
        this.PAB0 = PAB0;
    }

    public int getPAB1() {
        return PAB1;
    }

    public void setPAB1(int PAB1) {
        this.PAB1 = PAB1;
    }

    public int getPAB2() {
        return PAB2;
    }

    public void setPAB2(int PAB2) {
        this.PAB2 = PAB2;
    }

    public int getPAB3() {
        return PAB3;
    }

    public void setPAB3(int PAB3) {
        this.PAB3 = PAB3;
    }

    public int getPAB4() {
        return PAB4;
    }

    public void setPAB4(int PAB4) {
        this.PAB4 = PAB4;
    }

    public int getPAB5() {
        return PAB5;
    }

    public void setPAB5(int PAB5) {
        this.PAB5 = PAB5;
    }

    public int getPAB6() {
        return PAB6;
    }

    public void setPAB6(int PAB6) {
        this.PAB6 = PAB6;
    }

    public int getPAB7() {
        return PAB7;
    }

    public void setPAB7(int PAB7) {
        this.PAB7 = PAB7;
    }

    public int getPAB8() {
        return PAB8;
    }

    public void setPAB8(int PAB8) {
        this.PAB8 = PAB8;
    }

    public int getPAB9() {
        return PAB9;
    }

    public void setPAB9(int PAB9) {
        this.PAB9 = PAB9;
    }

    public int getPAB10() {
        return PAB10;
    }

    public void setPAB10(int PAB10) {
        this.PAB10 = PAB10;
    }

    public int getPAB11() {
        return PAB11;
    }

    public void setPAB11(int PAB11) {
        this.PAB11 = PAB11;
    }

    public int getPAB12() {
        return PAB12;
    }

    public void setPAB12(int PAB12) {
        this.PAB12 = PAB12;
    }

    public int getNR0() {
        return NR0;
    }

    public void setNR0(int NR0) {
        this.NR0 = NR0;
    }

    public int getNR1() {
        return NR1;
    }

    public void setNR1(int NR1) {
        this.NR1 = NR1;
    }

    public int getNR2() {
        return NR2;
    }

    public void setNR2(int NR2) {
        this.NR2 = NR2;
    }

    public int getNR3() {
        return NR3;
    }

    public void setNR3(int NR3) {
        this.NR3 = NR3;
    }

    public int getNR4() {
        return NR4;
    }

    public void setNR4(int NR4) {
        this.NR4 = NR4;
    }

    public int getNR5() {
        return NR5;
    }

    public void setNR5(int NR5) {
        this.NR5 = NR5;
    }

    public int getNR6() {
        return NR6;
    }

    public void setNR6(int NR6) {
        this.NR6 = NR6;
    }

    public int getNR7() {
        return NR7;
    }

    public void setNR7(int NR7) {
        this.NR7 = NR7;
    }

    public int getNR8() {
        return NR8;
    }

    public void setNR8(int NR8) {
        this.NR8 = NR8;
    }

    public int getNR9() {
        return NR9;
    }

    public void setNR9(int NR9) {
        this.NR9 = NR9;
    }

    public int getNR10() {
        return NR10;
    }

    public void setNR10(int NR10) {
        this.NR10 = NR10;
    }

    public int getNR11() {
        return NR11;
    }

    public void setNR11(int NR11) {
        this.NR11 = NR11;
    }

    public int getNR12() {
        return NR12;
    }

    public void setNR12(int NR12) {
        this.NR12 = NR12;
    }

    public int getPORcpt0() {
        return PORcpt0;
    }

    public void setPORcpt0(int PORcpt0) {
        this.PORcpt0 = PORcpt0;
    }

    public int getPORcpt1() {
        return PORcpt1;
    }

    public void setPORcpt1(int PORcpt1) {
        this.PORcpt1 = PORcpt1;
    }

    public int getPORcpt2() {
        return PORcpt2;
    }

    public void setPORcpt2(int PORcpt2) {
        this.PORcpt2 = PORcpt2;
    }

    public int getPORcpt3() {
        return PORcpt3;
    }

    public void setPORcpt3(int PORcpt3) {
        this.PORcpt3 = PORcpt3;
    }

    public int getPORcpt4() {
        return PORcpt4;
    }

    public void setPORcpt4(int PORcpt4) {
        this.PORcpt4 = PORcpt4;
    }

    public int getPORcpt5() {
        return PORcpt5;
    }

    public void setPORcpt5(int PORcpt5) {
        this.PORcpt5 = PORcpt5;
    }

    public int getPORcpt6() {
        return PORcpt6;
    }

    public void setPORcpt6(int PORcpt6) {
        this.PORcpt6 = PORcpt6;
    }

    public int getPORcpt7() {
        return PORcpt7;
    }

    public void setPORcpt7(int PORcpt7) {
        this.PORcpt7 = PORcpt7;
    }

    public int getPORcpt8() {
        return PORcpt8;
    }

    public void setPORcpt8(int PORcpt8) {
        this.PORcpt8 = PORcpt8;
    }

    public int getPORcpt9() {
        return PORcpt9;
    }

    public void setPORcpt9(int PORcpt9) {
        this.PORcpt9 = PORcpt9;
    }

    public int getPORcpt10() {
        return PORcpt10;
    }

    public void setPORcpt10(int PORcpt10) {
        this.PORcpt10 = PORcpt10;
    }

    public int getPORcpt11() {
        return PORcpt11;
    }

    public void setPORcpt11(int PORcpt11) {
        this.PORcpt11 = PORcpt11;
    }

    public int getPORcpt12() {
        return PORcpt12;
    }

    public void setPORcpt12(int PORcpt12) {
        this.PORcpt12 = PORcpt12;
    }

    public int getPOR0() {
        return POR0;
    }

    public void setPOR0(int POR0) {
        this.POR0 = POR0;
    }

    public int getPOR1() {
        return POR1;
    }

    public void setPOR1(int POR1) {
        this.POR1 = POR1;
    }

    public int getPOR2() {
        return POR2;
    }

    public void setPOR2(int POR2) {
        this.POR2 = POR2;
    }

    public int getPOR3() {
        return POR3;
    }

    public void setPOR3(int POR3) {
        this.POR3 = POR3;
    }

    public int getPOR4() {
        return POR4;
    }

    public void setPOR4(int POR4) {
        this.POR4 = POR4;
    }

    public int getPOR5() {
        return POR5;
    }

    public void setPOR5(int POR5) {
        this.POR5 = POR5;
    }

    public int getPOR6() {
        return POR6;
    }

    public void setPOR6(int POR6) {
        this.POR6 = POR6;
    }

    public int getPOR7() {
        return POR7;
    }

    public void setPOR7(int POR7) {
        this.POR7 = POR7;
    }

    public int getPOR8() {
        return POR8;
    }

    public void setPOR8(int POR8) {
        this.POR8 = POR8;
    }

    public int getPOR9() {
        return POR9;
    }

    public void setPOR9(int POR9) {
        this.POR9 = POR9;
    }

    public int getPOR10() {
        return POR10;
    }

    public void setPOR10(int POR10) {
        this.POR10 = POR10;
    }

    public int getPOR11() {
        return POR11;
    }

    public void setPOR11(int POR11) {
        this.POR11 = POR11;
    }

    public int getPOR12() {
        return POR12;
    }

    public void setPOR12(int POR12) {
        this.POR12 = POR12;
    }

    @Override
    public String toString() {
        return "TPOP{" +
                "id=" + id +
                ", P_No='" + P_No + '\'' +
                ", OH='" + OH + '\'' +
                ", AL='" + AL + '\'' +
                ", LT=" + LT +
                ", ST=" + ST +
                ", SS=" + SS +
                ", LSR='" + LSR + '\'' +
                ", LS=" + LS +
                "\n"+
                ", GR0=" + GR0 +
                ", GR1=" + GR1 +
                ", GR2=" + GR2 +
                ", GR3=" + GR3 +
                ", GR4=" + GR4 +
                ", GR5=" + GR5 +
                ", GR6=" + GR6 +
                ", GR7=" + GR7 +
                ", GR8=" + GR8 +
                ", GR9=" + GR9 +
                ", GR10=" + GR10 +
                ", GR11=" + GR11 +
                ", GR12=" + GR12 +
                "\n"+
                ", SR0=" + SR0 +
                ", SR1=" + SR1 +
                ", SR2=" + SR2 +
                ", SR3=" + SR3 +
                ", SR4=" + SR4 +
                ", SR5=" + SR5 +
                ", SR6=" + SR6 +
                ", SR7=" + SR7 +
                ", SR8=" + SR8 +
                ", SR9=" + SR9 +
                ", SR10=" + SR10 +
                ", SR11=" + SR11 +
                ", SR12=" + SR12 +
                "\n"+
                ", POH0=" + POH0 +
                ", POH1=" + POH1 +
                ", POH2=" + POH2 +
                ", POH3=" + POH3 +
                ", POH4=" + POH4 +
                ", POH5=" + POH5 +
                ", POH6=" + POH6 +
                ", POH7=" + POH7 +
                ", POH8=" + POH8 +
                ", POH9=" + POH9 +
                ", POH10=" + POH10 +
                ", POH11=" + POH11 +
                ", POH12=" + POH12 +
                "\n"+
                ", PAB0=" + PAB0 +
                ", PAB1=" + PAB1 +
                ", PAB2=" + PAB2 +
                ", PAB3=" + PAB3 +
                ", PAB4=" + PAB4 +
                ", PAB5=" + PAB5 +
                ", PAB6=" + PAB6 +
                ", PAB7=" + PAB7 +
                ", PAB8=" + PAB8 +
                ", PAB9=" + PAB9 +
                ", PAB10=" + PAB10 +
                ", PAB11=" + PAB11 +
                ", PAB12=" + PAB12 +
                "\n"+
                ", NR0=" + NR0 +
                ", NR1=" + NR1 +
                ", NR2=" + NR2 +
                ", NR3=" + NR3 +
                ", NR4=" + NR4 +
                ", NR5=" + NR5 +
                ", NR6=" + NR6 +
                ", NR7=" + NR7 +
                ", NR8=" + NR8 +
                ", NR9=" + NR9 +
                ", NR10=" + NR10 +
                ", NR11=" + NR11 +
                ", NR12=" + NR12 +
                "\n"+
                ", PORcpt0=" + PORcpt0 +
                ", PORcpt1=" + PORcpt1 +
                ", PORcpt2=" + PORcpt2 +
                ", PORcpt3=" + PORcpt3 +
                ", PORcpt4=" + PORcpt4 +
                ", PORcpt5=" + PORcpt5 +
                ", PORcpt6=" + PORcpt6 +
                ", PORcpt7=" + PORcpt7 +
                ", PORcpt8=" + PORcpt8 +
                ", PORcpt9=" + PORcpt9 +
                ", PORcpt10=" + PORcpt10 +
                ", PORcpt11=" + PORcpt11 +
                ", PORcpt12=" + PORcpt12 +
                "\n"+
                ", POR0=" + POR0 +
                ", POR1=" + POR1 +
                ", POR2=" + POR2 +
                ", POR3=" + POR3 +
                ", POR4=" + POR4 +
                ", POR5=" + POR5 +
                ", POR6=" + POR6 +
                ", POR7=" + POR7 +
                ", POR8=" + POR8 +
                ", POR9=" + POR9 +
                ", POR10=" + POR10 +
                ", POR11=" + POR11 +
                ", POR12=" + POR12 +
                '}';
    }
}
