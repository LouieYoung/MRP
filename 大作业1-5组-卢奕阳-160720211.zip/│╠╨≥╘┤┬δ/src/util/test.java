package util;

import entity.BOM;

import static util.MRPUtils.MRP;

public class test {
    public static void main(String[] args) {
        MRP();
    }
}
